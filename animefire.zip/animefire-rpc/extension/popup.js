function formatTime(seconds) {
  if (!seconds || isNaN(seconds)) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function render(data, connected) {
  const dot = document.getElementById('dot');
  const statusText = document.getElementById('statusText');
  const content = document.getElementById('content');
  const noData = document.getElementById('noData');

  if (connected) {
    dot.classList.add('connected');
    statusText.textContent = 'Conectado ao servidor Python ✓';
  } else {
    dot.classList.remove('connected');
    statusText.textContent = 'Servidor Python não encontrado';
  }

  if (!data) return;

  noData.style.display = 'none';

  const pct = data.duration > 0 ? ((data.currentTime / data.duration) * 100).toFixed(1) : 0;

  content.innerHTML = `
    <div class="info-block">
      <div class="info-label">🎬 Anime</div>
      <div class="info-value" title="${data.animeTitle}">${data.animeTitle}</div>
    </div>

    <div class="info-block">
      <div class="info-label">📺 Episódio</div>
      <div class="info-value">${data.episode}</div>
    </div>

    <div class="info-block">
      <div class="info-label">⏱ Progresso • ${data.paused ? '⏸ Pausado' : '▶ Assistindo'}</div>
      <div class="progress-wrap">
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${pct}%"></div>
        </div>
        <div class="progress-times">
          <span>${formatTime(data.currentTime)}</span>
          <span>${formatTime(data.duration)}</span>
        </div>
      </div>
    </div>
  `;
}

// Busca status do background
chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
  if (response) {
    render(response.lastData, response.isConnected);
  }
});
