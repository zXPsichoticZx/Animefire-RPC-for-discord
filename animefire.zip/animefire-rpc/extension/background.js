// =============================================
// AnimeFire RPC - Background Service Worker
// Recebe dados do content script e envia
// para o servidor local Python (porta 6969)
// =============================================

const SERVER_URL = 'http://localhost:6969/update';

let lastData = null;
let isConnected = false;

async function sendToServer(payload) {
  try {
    const response = await fetch(SERVER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      isConnected = true;
      // Atualiza ícone para verde (conectado)
      chrome.action.setBadgeText({ text: '●' });
      chrome.action.setBadgeBackgroundColor({ color: '#57F287' });
    } else {
      throw new Error(`HTTP ${response.status}`);
    }
  } catch (err) {
    isConnected = false;
    // Ícone vermelho = servidor Python não tá rodando
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#ED4245' });
    console.warn('[AnimeFire RPC] Servidor local não encontrado. Rode o script Python!');
  }
}

async function sendStopped() {
  try {
    await fetch('http://localhost:6969/stop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stopped: true })
    });
  } catch (e) {}
}

// Escuta mensagens do content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'ANIME_DATA') {
    lastData = message.payload;
    sendToServer(message.payload);
  } else if (message.type === 'ANIME_STOPPED') {
    sendStopped();
    chrome.action.setBadgeText({ text: '' });
  } else if (message.type === 'GET_STATUS') {
    sendResponse({ isConnected, lastData });
  }
  return true;
});

// Badge inicial
chrome.action.setBadgeText({ text: '' });
