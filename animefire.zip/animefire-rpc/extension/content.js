// =============================================
// AnimeFire RPC - Content Script
// Captura título, episódio, tempo e duração
// =============================================

let lastSentData = null;
let intervalId = null;

function getAnimeData() {
  try {
    // --- TÍTULO DO ANIME ---
    // Tenta múltiplos seletores comuns do AnimeFire
    let animeTitle =
      document.querySelector('h1.title-anime')?.innerText?.trim() ||
      document.querySelector('.anime-title')?.innerText?.trim() ||
      document.querySelector('h1')?.innerText?.trim() ||
      document.title?.replace(/ - AnimeFire.*/, '').trim() ||
      'Anime desconhecido';

    // --- EPISÓDIO ---
    let episode =
      document.querySelector('.ep-title')?.innerText?.trim() ||
      document.querySelector('.episode-title')?.innerText?.trim() ||
      document.querySelector('.current-ep')?.innerText?.trim() ||
      null;

    // Tenta extrair episódio da URL: /video/anime-name/1
    if (!episode) {
      const urlMatch = window.location.pathname.match(/\/(\d+)\/?$/);
      if (urlMatch) {
        episode = `Episódio ${urlMatch[1]}`;
      }
    }

    if (!episode) episode = 'Episódio desconhecido';

    // --- PLAYER DE VÍDEO ---
    // Suporte a <video> nativo e iframes (ex: Blogger, Streamtape, etc.)
    let video = document.querySelector('video');

    // Se não achou video direto, tenta dentro de iframes same-origin
    if (!video) {
      const iframes = document.querySelectorAll('iframe');
      for (const iframe of iframes) {
        try {
          const iDoc = iframe.contentDocument || iframe.contentWindow?.document;
          if (iDoc) {
            video = iDoc.querySelector('video');
            if (video) break;
          }
        } catch (e) {
          // Cross-origin, ignora
        }
      }
    }

    let currentTime = 0;
    let duration = 0;
    let paused = true;

    if (video) {
      currentTime = Math.floor(video.currentTime) || 0;
      duration = Math.floor(video.duration) || 0;
      paused = video.paused;
    }

    // --- URL ATUAL (para o botão) ---
    const currentUrl = window.location.href;

    const data = {
      animeTitle,
      episode,
      currentTime,
      duration,
      paused,
      currentUrl,
      timestamp: Date.now()
    };

    return data;
  } catch (err) {
    console.error('[AnimeFire RPC] Erro ao capturar dados:', err);
    return null;
  }
}

function sendDataToBackground() {
  const data = getAnimeData();
  if (!data) return;

  // Só manda se mudou algo relevante (evita spam)
  const key = `${data.animeTitle}|${data.episode}|${data.currentTime}|${data.paused}`;
  if (key === lastSentData) return;
  lastSentData = key;

  chrome.runtime.sendMessage({ type: 'ANIME_DATA', payload: data });
}

// Começa a capturar assim que a página carrega
function startCapture() {
  if (intervalId) clearInterval(intervalId);
  intervalId = setInterval(sendDataToBackground, 2000); // a cada 2 segundos
  console.log('[AnimeFire RPC] Captura iniciada.');
}

// Para quando o usuário sai da aba
function stopCapture() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
  chrome.runtime.sendMessage({ type: 'ANIME_STOPPED' });
}

// Inicia
startCapture();

// Para quando fecha/muda de aba
window.addEventListener('beforeunload', stopCapture);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    stopCapture();
  } else {
    startCapture();
  }
});
