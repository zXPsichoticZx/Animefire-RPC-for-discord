"""
AnimeFire Discord RPC - Full Edition v3
========================================
Novidades v3:
  - Dashboard web em http://localhost:6969/dashboard
  - Rota /history para o dashboard ler histórico
  - Abre dashboard automaticamente ao iniciar

Dependências:
  pip install pypresence flask flask-cors requests beautifulsoup4 winotify

Como usar:
  python rpc.py
  python rpc.py --autostart
  python rpc.py --remove-autostart
  python rpc.py --no-browser      (não abre o dashboard automaticamente)
"""

import threading
import time
import sys
import os
import json
import argparse
import atexit
import datetime
import webbrowser
import requests
from bs4 import BeautifulSoup
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from pypresence import Presence, DiscordNotFound

try:
    from winotify import Notification, audio
    WINOTIFY_AVAILABLE = True
except ImportError:
    WINOTIFY_AVAILABLE = False

# ======================
#   CONFIGURAÇÕES
# ======================

CLIENT_ID    = "SEU_CLIENT_ID_AQUI"
PROFILE_URL  = "https://animefire.io/users/980912491"
SITE_URL     = "https://animefire.io/"
PORT         = 6969
LARGE_IMAGE  = "logo_xeon"
SMALL_PLAY   = "play_icon"
SMALL_PAUSE  = "pause_icon"

AFK_TIMEOUT  = 5 * 60
CACHE_FILE   = "thumbnail_cache.json"
HISTORY_FILE = "session_history.json"

# Caminho do dashboard HTML (mesma pasta do script)
DASHBOARD_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard.html")

# ======================
#   ESTADO GLOBAL
# ======================

current_data        = None
rpc                 = None
rpc_connected       = False
last_update         = 0
last_active_time    = time.time()
session_start       = time.time()

session_episodes    = []
last_episode_key    = None
thumbnail_cache     = {}

frozen_remaining    = None
frozen_at           = None

total_watch_seconds = 0
watch_start_epoch   = None

# ======================
#   UTILS
# ======================

def format_time(seconds):
    if not seconds or seconds <= 0:
        return "0:00"
    return f"{int(seconds // 60)}:{int(seconds % 60):02d}"

def format_duration(seconds):
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    if h > 0:
        return f"{h}h{m:02d}m"
    return f"{m}m"

def is_night():
    hour = datetime.datetime.now().hour
    return hour >= 22 or hour < 6

# ======================
#   CACHE / HISTÓRICO
# ======================

def load_cache():
    global thumbnail_cache
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                thumbnail_cache = json.load(f)
        except Exception:
            thumbnail_cache = {}

def save_cache():
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(thumbnail_cache, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def load_history():
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []

def save_history():
    global total_watch_seconds, watch_start_epoch
    if watch_start_epoch:
        total_watch_seconds += time.time() - watch_start_epoch

    history = load_history()
    session = {
        "date":           datetime.datetime.now().strftime("%d/%m/%Y %H:%M"),
        "episodes_count": len(session_episodes),
        "episodes":       session_episodes,
        "watch_time":     format_duration(total_watch_seconds),
        "watch_seconds":  int(total_watch_seconds),
    }
    history.append(session)
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
        print(f"\n[HISTÓRICO] Sessão salva: {len(session_episodes)} ep(s), {format_duration(total_watch_seconds)}.")
    except Exception as e:
        print(f"[HISTÓRICO] Erro: {e}")

# ======================
#   THUMBNAIL
# ======================

def get_thumbnail_url(current_url: str):
    slug = None
    try:
        parts = current_url.replace("https://animefire.io/", "").split("/")
        if len(parts) >= 2 and parts[0] == "video":
            slug = parts[1]
    except Exception:
        pass
    if not slug:
        return None
    if slug in thumbnail_cache:
        return thumbnail_cache[slug]
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        resp    = requests.get(f"https://animefire.io/animes/{slug}", headers=headers, timeout=5)
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.text, "html.parser")
            img  = (
                soup.select_one(".anime-cover img") or
                soup.select_one(".cover img") or
                soup.select_one("img.img-fluid") or
                soup.select_one("meta[property='og:image']")
            )
            url = img.get("src") or img.get("content") if img else None
            if url:
                thumbnail_cache[slug] = url
                save_cache()
                print(f"[THUMB] ✓ '{slug}'")
                return url
    except Exception as e:
        print(f"[THUMB] Falha: {e}")
    return None

# ======================
#   NOTIFICAÇÕES
# ======================

def notify(title: str, message: str):
    if not WINOTIFY_AVAILABLE:
        print(f"[NOTIF] {title} — {message}")
        return
    try:
        toast = Notification(app_id="AnimeFire RPC", title=title, msg=message)
        toast.set_audio(audio.Default, loop=False)
        toast.show()
    except Exception as e:
        print(f"[NOTIF] Erro: {e}")

# ======================
#   DISCORD RPC
# ======================

def connect_rpc():
    global rpc, rpc_connected
    print("[RPC] Conectando ao Discord...")
    try:
        rpc = Presence(CLIENT_ID)
        rpc.connect()
        rpc_connected = True
        print("[RPC] ✓ Conectado!")
        notify("AnimeFire RPC 🔥", "Conectado! Abre o AnimeFire e bora.")
    except DiscordNotFound:
        print("[RPC] ✗ Discord não encontrado!")
        sys.exit(1)
    except Exception as e:
        print(f"[RPC] ✗ Erro: {e}")
        sys.exit(1)

def reconnect_loop():
    global rpc, rpc_connected
    rpc_connected = False
    print("[RPC] Discord fechou. Aguardando...")
    while True:
        try:
            time.sleep(5)
            rpc = Presence(CLIENT_ID)
            rpc.connect()
            rpc_connected = True
            print("[RPC] ✓ Reconectado!")
            notify("AnimeFire RPC 🔥", "Reconectado ao Discord!")
            return
        except Exception:
            print("[RPC] Ainda aguardando Discord...")

def track_episode(anime_title: str, episode: str):
    global last_episode_key, session_episodes
    key = f"{anime_title}|{episode}"
    if key == last_episode_key:
        return
    last_episode_key = key
    entry = f"{anime_title} - {episode}"
    if entry not in session_episodes:
        session_episodes.append(entry)
        count = len(session_episodes)
        print(f"[SESSÃO] Ep {count}: {entry}")
        if count > 1:
            notify("AnimeFire RPC 📺", f"Ep {count} na sessão!\n{episode} • {anime_title}")

def update_presence(data):
    global rpc, rpc_connected, last_update, last_active_time
    global frozen_remaining, frozen_at, watch_start_epoch, total_watch_seconds

    if not rpc_connected or not rpc:
        return

    now = time.time()
    if now - last_update < 3:
        return
    last_update = now

    anime_title = data.get("animeTitle", "Anime desconhecido")
    episode     = data.get("episode", "Episódio desconhecido")
    current_t   = data.get("currentTime", 0)
    duration    = data.get("duration", 0)
    paused      = data.get("paused", True)
    current_url = data.get("currentUrl", SITE_URL)

    if not paused:
        if watch_start_epoch is None:
            watch_start_epoch = now
        frozen_remaining = None
        frozen_at        = None
        track_episode(anime_title, episode)
        last_active_time = now
    else:
        if watch_start_epoch is not None:
            total_watch_seconds += now - watch_start_epoch
            watch_start_epoch = None
        if frozen_remaining is None and duration > 0:
            frozen_remaining = max(0, duration - current_t)
            frozen_at        = now

    afk_seconds = now - last_active_time
    is_afk      = paused and afk_seconds >= AFK_TIMEOUT

    if not paused and duration > 0:
        end_time = int(now) + int(duration - current_t)
    elif paused and frozen_remaining is not None:
        end_time = int(now) + int(frozen_remaining)
    else:
        end_time = None

    if is_afk:
        small_image = SMALL_PAUSE
        small_text  = f"💤 AFK há {int(afk_seconds // 60)} min"
        state_text  = f"💤 AFK • {episode}"
    elif paused:
        small_image = SMALL_PAUSE
        small_text  = "⏸ Pausado"
        state_text  = f"⏸ {episode}"
    else:
        night = "🌙 " if is_night() else ""
        small_image = SMALL_PLAY
        small_text  = f"{night}▶ Ep {len(session_episodes)} na sessão • {format_duration(total_watch_seconds)} assistidos"
        state_text  = episode

    watch_url = current_url if current_url.startswith("https://animefire.io") else SITE_URL
    buttons   = [
        {"label": "▶ Assistir Anime", "url": watch_url},
        {"label": "👤 Meu Perfil",    "url": PROFILE_URL},
    ]

    try:
        rpc.update(
            details     = anime_title,
            state       = state_text,
            large_image = LARGE_IMAGE,
            large_text  = "AnimeFire.io",
            small_image = small_image,
            small_text  = small_text,
            end         = end_time,
            buttons     = buttons,
        )
        icon = "💤" if is_afk else ("⏸" if paused else "▶")
        print(f"[RPC] {icon} {anime_title} | {state_text} | {format_duration(total_watch_seconds)}")
    except Exception as e:
        print(f"[RPC] Erro: {e}")
        threading.Thread(target=reconnect_loop, daemon=True).start()

def clear_presence():
    if rpc_connected and rpc:
        try:
            rpc.clear()
            print("[RPC] Presence limpo.")
        except Exception:
            pass

# ======================
#   SERVIDOR HTTP
# ======================

app = Flask(__name__)
CORS(app)

@app.route("/dashboard")
def dashboard():
    return send_file(DASHBOARD_PATH)

@app.route("/update", methods=["POST"])
def update():
    global current_data
    data = request.get_json()
    if not data:
        return jsonify({"error": "sem dados"}), 400
    current_data = data
    threading.Thread(target=update_presence, args=(data,), daemon=True).start()
    return jsonify({"ok": True})

@app.route("/stop", methods=["POST"])
def stop():
    global current_data
    current_data = None
    threading.Thread(target=clear_presence, daemon=True).start()
    return jsonify({"ok": True})

@app.route("/status", methods=["GET"])
def status():
    current_ws = (time.time() - watch_start_epoch) if watch_start_epoch else 0
    return jsonify({
        "rpc_connected":    rpc_connected,
        "episode_count":    len(session_episodes),
        "session_episodes": session_episodes,
        "watch_time":       format_duration(total_watch_seconds + current_ws),
        "watch_seconds":    int(total_watch_seconds + current_ws),
        "current_data":     current_data,
    })

@app.route("/history", methods=["GET"])
def history():
    return jsonify({"history": load_history()})

# ======================
#   AUTO-START WINDOWS
# ======================

def get_bat_path():
    startup = os.path.join(
        os.environ.get("APPDATA", ""),
        r"Microsoft\Windows\Start Menu\Programs\Startup"
    )
    return os.path.join(startup, "AnimeFireRPC.bat")

def add_autostart():
    bat = f'@echo off\nstart "" /MIN "{sys.executable}" "{os.path.abspath(__file__)}"\n'
    try:
        with open(get_bat_path(), "w") as f:
            f.write(bat)
        print(f"[AUTOSTART] ✓ Ativado!")
        notify("AnimeFire RPC 🔥", "Auto-start ativado!")
    except Exception as e:
        print(f"[AUTOSTART] Erro: {e}")

def remove_autostart():
    path = get_bat_path()
    if os.path.exists(path):
        os.remove(path)
        print("[AUTOSTART] ✓ Removido.")
    else:
        print("[AUTOSTART] Nenhum auto-start encontrado.")

# ======================
#   MAIN
# ======================

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--autostart",        action="store_true")
    parser.add_argument("--remove-autostart", action="store_true")
    parser.add_argument("--no-browser",       action="store_true", help="Não abre o dashboard automaticamente")
    args = parser.parse_args()

    if args.autostart:
        add_autostart(); sys.exit(0)
    if args.remove_autostart:
        remove_autostart(); sys.exit(0)

    print("=" * 50)
    print("  AnimeFire Discord RPC — Full Edition v3")
    print("=" * 50)

    if CLIENT_ID == "SEU_CLIENT_ID_AQUI":
        print("\n⚠️  Cola seu CLIENT_ID no topo do arquivo!\n")
        sys.exit(1)

    load_cache()
    atexit.register(save_history)
    connect_rpc()

    dashboard_url = f"http://localhost:{PORT}/dashboard"
    print(f"\n[HTTP] http://localhost:{PORT}")
    print(f"[DASHBOARD] {dashboard_url}")
    print("[HTTP] Aguardando dados da extensão...\n")

    # Abre o dashboard no navegador após 1.5s
    if not args.no_browser:
        def open_browser():
            time.sleep(1.5)
            webbrowser.open(dashboard_url)
            print(f"[DASHBOARD] Aberto no navegador!")
        threading.Thread(target=open_browser, daemon=True).start()

    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)

    app.run(host="127.0.0.1", port=PORT, debug=False)
